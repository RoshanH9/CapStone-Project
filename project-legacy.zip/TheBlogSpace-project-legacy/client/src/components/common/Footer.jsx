import React from 'react'

function Footer() {
  return (
    <div className='p-5 bg-dark text-white '>Footer</div>
  )
}

export default Footer